# Nguồn của agent `agency-gis-geoprocessing-specialist`

Một agent lẻ của gói `naota.agency-agents`, lấy từ [msitarzewski/agency-agents/gis/gis-geoprocessing-specialist.md](https://github.com/msitarzewski/agency-agents/blob/main/gis/gis-geoprocessing-specialist.md).
Thân prompt chép nguyên văn, phần đầu tệp thêm khoá cho Naota (xem `docs/NGUON.md` của gói gộp).
Repo gốc đổi agent này thì gói lên một bản vá, Naota báo trong chuông.

Giấy phép gốc: **MIT**, nguyên văn ở `docs/LICENSE-goc*`.
