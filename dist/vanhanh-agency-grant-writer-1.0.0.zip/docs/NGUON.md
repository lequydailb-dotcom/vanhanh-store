# Nguồn của agent `agency-grant-writer`

Một agent lẻ của gói `vanhanh.agency-agents`, lấy từ [msitarzewski/agency-agents/specialized/grant-writer.md](https://github.com/msitarzewski/agency-agents/blob/main/specialized/grant-writer.md).
Thân prompt chép nguyên văn, phần đầu tệp thêm khoá cho Vanhanh (xem `docs/NGUON.md` của gói gộp).
Repo gốc đổi agent này thì gói lên một bản vá, Vanhanh báo trong chuông.

Giấy phép gốc: **MIT**, nguyên văn ở `docs/LICENSE-goc*`.
