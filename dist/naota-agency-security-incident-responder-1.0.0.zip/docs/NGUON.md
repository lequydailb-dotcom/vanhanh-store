# Nguồn của agent `agency-security-incident-responder`

Một agent lẻ của gói `naota.agency-agents`, lấy từ [msitarzewski/agency-agents/security/security-incident-responder.md](https://github.com/msitarzewski/agency-agents/blob/main/security/security-incident-responder.md).
Thân prompt chép nguyên văn, phần đầu tệp thêm khoá cho Naota (xem `docs/NGUON.md` của gói gộp).
Repo gốc đổi agent này thì gói lên một bản vá, Naota báo trong chuông.

Giấy phép gốc: **MIT**, nguyên văn ở `docs/LICENSE-goc*`.
