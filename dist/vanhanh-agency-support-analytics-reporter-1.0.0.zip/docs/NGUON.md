# Nguồn của agent `agency-support-analytics-reporter`

Một agent lẻ của gói `vanhanh.agency-agents`, lấy từ [msitarzewski/agency-agents/support/support-analytics-reporter.md](https://github.com/msitarzewski/agency-agents/blob/main/support/support-analytics-reporter.md).
Thân prompt chép nguyên văn, phần đầu tệp thêm khoá cho Vanhanh (xem `docs/NGUON.md` của gói gộp).
Repo gốc đổi agent này thì gói lên một bản vá, Vanhanh báo trong chuông.

Giấy phép gốc: **MIT**, nguyên văn ở `docs/LICENSE-goc*`.
