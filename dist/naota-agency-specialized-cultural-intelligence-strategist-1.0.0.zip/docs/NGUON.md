# Nguồn của agent `agency-specialized-cultural-intelligence-strategist`

Một agent lẻ của gói `naota.agency-agents`, lấy từ [msitarzewski/agency-agents/specialized/specialized-cultural-intelligence-strategist.md](https://github.com/msitarzewski/agency-agents/blob/main/specialized/specialized-cultural-intelligence-strategist.md).
Thân prompt chép nguyên văn, phần đầu tệp thêm khoá cho Naota (xem `docs/NGUON.md` của gói gộp).
Repo gốc đổi agent này thì gói lên một bản vá, Naota báo trong chuông.

Giấy phép gốc: **MIT**, nguyên văn ở `docs/LICENSE-goc*`.
