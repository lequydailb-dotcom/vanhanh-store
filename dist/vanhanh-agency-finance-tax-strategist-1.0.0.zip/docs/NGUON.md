# Nguồn của agent `agency-finance-tax-strategist`

Một agent lẻ của gói `vanhanh.agency-agents`, lấy từ [msitarzewski/agency-agents/finance/finance-tax-strategist.md](https://github.com/msitarzewski/agency-agents/blob/main/finance/finance-tax-strategist.md).
Thân prompt chép nguyên văn, phần đầu tệp thêm khoá cho Vanhanh (xem `docs/NGUON.md` của gói gộp).
Repo gốc đổi agent này thì gói lên một bản vá, Vanhanh báo trong chuông.

Giấy phép gốc: **MIT**, nguyên văn ở `docs/LICENSE-goc*`.
