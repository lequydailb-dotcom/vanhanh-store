# Nguồn của agent `agency-project-management-experiment-tracker`

Một agent lẻ của gói `vanhanh.agency-agents`, lấy từ [msitarzewski/agency-agents/project-management/project-management-experiment-tracker.md](https://github.com/msitarzewski/agency-agents/blob/main/project-management/project-management-experiment-tracker.md).
Thân prompt chép nguyên văn, phần đầu tệp thêm khoá cho Vanhanh (xem `docs/NGUON.md` của gói gộp).
Repo gốc đổi agent này thì gói lên một bản vá, Vanhanh báo trong chuông.

Giấy phép gốc: **MIT**, nguyên văn ở `docs/LICENSE-goc*`.
